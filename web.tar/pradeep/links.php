<a href='display.php'>Dispaly</a><br >
<a href='logout.php'>Logout</a><br >
<a href='register.php'>Complaint</a><br >
<a href='search.php'>Search</a><br >
